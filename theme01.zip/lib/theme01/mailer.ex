defmodule Theme01.Mailer do
  use Swoosh.Mailer, otp_app: :theme01
end
