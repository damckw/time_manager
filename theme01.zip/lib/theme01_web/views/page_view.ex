defmodule Theme01Web.PageView do
  use Theme01Web, :view
end
