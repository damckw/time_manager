alias Theme01.Repo

alias Theme01.API.User



Repo.insert! %User{

username: "Test1",

email: "1test"

}



Repo.insert! %User{

username: "Test2",

email: "2test"

}