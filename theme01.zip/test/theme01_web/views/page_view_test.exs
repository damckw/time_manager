defmodule Theme01Web.PageViewTest do
  use Theme01Web.ConnCase, async: true
end
